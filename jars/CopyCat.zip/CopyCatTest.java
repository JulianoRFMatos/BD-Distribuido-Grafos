package br.ufu.server.copycat;

import br.ufu.server.copycat.command.Put;
import br.ufu.server.copycat.query.Get;
import io.atomix.catalyst.transport.Address;
import io.atomix.copycat.client.ConnectionStrategies;
import io.atomix.copycat.client.CopycatClient;
import io.atomix.copycat.server.CopycatServer;
import io.atomix.copycat.server.storage.Storage;
import io.atomix.copycat.server.storage.StorageLevel;
import org.junit.Before;
import org.junit.Test;

/**
 * Created by gustavomahlow on 11/07/17.
 */
public class CopyCatTest {

    private CopycatServer copycatServer;
    private CopycatServer copycatServer2;

    private CopycatClient copyCatClient;
    private CopycatClient copyCatClient2;

    @Before
    public void setUp() throws Exception {
        copycatServer = CopycatServer.builder(new Address("localhost", 5500))
                .withStorage(
                        Storage.builder()
                                .withStorageLevel(StorageLevel.MEMORY)
                                .build()
                )
                .withStateMachine(CopyCatStateMachine::new)
                .build();
        copycatServer.bootstrap().join();

        copycatServer2 = CopycatServer.builder(new Address("localhost", 5501))
                .withStorage(
                        Storage.builder()
                                .withStorageLevel(StorageLevel.MEMORY)
                                .build()
                )
                .withStateMachine(CopyCatStateMachine::new)
                .build();
        copycatServer2.join(new Address("localhost", 5500)).join();

        copyCatClient = CopycatClient.builder(new Address("localhost", 5501))
                .withConnectionStrategy(ConnectionStrategies.FIBONACCI_BACKOFF)
                .build();
        copyCatClient2 = CopycatClient.builder(new Address("localhost", 5500))
                .withConnectionStrategy(ConnectionStrategies.FIBONACCI_BACKOFF)
                .build();

        copyCatClient.connect().join();
        copyCatClient2.connect().join();
    }

    @Test
    public void copyCatTest() throws Exception {
        copyCatClient.submit(new Put(10, "Teste")).join();
        System.out.println(copyCatClient2.submit(new Get(10)).join());
    }
}
